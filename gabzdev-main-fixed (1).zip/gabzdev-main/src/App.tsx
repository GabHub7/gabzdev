import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { AnimatePresence } from 'framer-motion';
import { ViewContext, type View } from './context/ViewContext';
import { LanguageProvider } from './context/LanguageContext';
import { supabase } from './lib/supabaseClient';
import Header from './sections/Header';
import Hero from './sections/Hero';
import Packages from './sections/Packages';
import About from './sections/About';
import Footer from './sections/Footer';
import CustomCursor from './components/CustomCursor';

// Section di bawah fold — lazy supaya bundle awal (LCP) tetap kecil.
// Struktur baru (5 section + skill stack): Hero -> SkillsCarousel -> About
// -> Packages -> Portfolio -> Footer (Contact + Testimoni digabung).
// StatsBar, AIWorkflow, Services (list lama), WhyHireMe, TrustedBy, dan
// Testimonials yang berdiri sendiri sengaja di-drop dari alur ini.
const SkillsCarousel = lazy(() => import('./sections/SkillsCarousel'));
const Portfolio = lazy(() => import('./sections/Portfolio'));

const AllProjects = lazy(() => import('./views/AllProjects'));

// Panel admin cuma dipakai sama Ciko, jadi dipisah dari bundle utama —
// pengunjung biasa nggak perlu download kode dashboard-nya.
const Login = lazy(() => import('./views/Login'));
const Dashboard = lazy(() => import('./views/Dashboard'));
import ScrollProgress from './components/ScrollProgress';
import SmoothScroll from './components/SmoothScroll';
import LoadingScreen from './components/LoadingScreen';
import WhatsAppFloating from './components/WhatsAppFloating';
import { hasSeenIntro, markIntroSeen } from './lib/intro';

// Kunci rahasia untuk masuk ke gerbang admin lewat link (dipakai oleh GabzStore
// saat tombol brand-nya diklik 3x). Bukan satu-satunya proteksi -- proteksi
// sesungguhnya tetap password Supabase Auth di halaman Login.
const ADMIN_ENTRY_PARAM = 'gx';
const ADMIN_ENTRY_VALUE = 'gz774';

// Lenis cuma untuk halaman publik (portfolio & projects) — bukan dashboard,
// biar scroll di form admin tetap native dan nggak "ketahan" momentum.
function SmoothScrollGate({ view, children }: { view: View; children: React.ReactNode }) {
  if (view === 'portfolio' || view === 'projects') {
    return <SmoothScroll>{children}</SmoothScroll>;
  }
  return <>{children}</>;
}

export default function App() {
  const [view, setView] = useState<View>('portfolio');
  const [booting, setBooting] = useState(true);
  // Intro cuma diputar sekali per sesi browser.
  const [showIntro, setShowIntro] = useState(() => !hasSeenIntro());

  const finishIntro = useCallback(() => {
    markIntroSeen();
    setShowIntro(false);
  }, []);

  useEffect(() => {
    // 1) Cek trigger rahasia dari URL (dipakai saat redirect dari GabzStore)
    const params = new URLSearchParams(window.location.search);
    const hasSecretEntry = params.get(ADMIN_ENTRY_PARAM) === ADMIN_ENTRY_VALUE;
    if (hasSecretEntry) {
      // Bersihkan URL supaya jejaknya hilang dari address bar / history
      params.delete(ADMIN_ENTRY_PARAM);
      const cleanUrl = window.location.pathname + (params.toString() ? `?${params}` : '') + window.location.hash;
      window.history.replaceState(null, '', cleanUrl);
    }

    // 2) Cek apakah sudah ada sesi admin aktif (biar gak logout tiap refresh)
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        setView('dashboard');
      } else if (hasSecretEntry) {
        setView('login');
      }
      setBooting(false);
    });

    // 3) Dengerin perubahan auth (logout dari tombol dashboard, dsb)
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        setView((v) => (v === 'dashboard' ? 'portfolio' : v));
      }
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  /**
   * KUNCI LAYOUT KE SUSUNAN DESKTOP.
   *
   * Masalah sebelumnya: tiap kali dibuka di HP, layout-nya "reflow" —
   * elemen yang di desktop sejajar jadi numpuk ke bawah, proporsi
   * berantakan, dan tiap section harus di-tambal satu-satu pakai
   * breakpoint. Nggak akan pernah kelar karena jumlah lebar layar HP itu
   * tak terhingga.
   *
   * Solusinya: viewport-nya dikunci ke lebar desktop tetap (1280px).
   * Browser HP otomatis nge-zoom-out seluruh halaman biar muat — jadi
   * yang tampil di HP itu KOMPOSISI DESKTOP PERSIS, cuma diperkecil.
   * Nggak ada lagi elemen yang pindah posisi/kabur, layer boleh numpuk
   * tapi susunannya tetap sama di semua device.
   *
   * Dikecualikan buat Dashboard & Login: itu area kerja admin yang
   * sering dibuka dari HP, kalau ikut dikunci 1280 tulisannya bakal
   * kekecilan buat ngetik. Jadi dua view itu tetap width=device-width.
   */
  useEffect(() => {
    const meta = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
    if (!meta) return;
    const isPublicSite = view === 'portfolio' || view === 'projects';
    meta.setAttribute(
      'content',
      isPublicSite ? 'width=1280, initial-scale=0' : 'width=device-width, initial-scale=1.0'
    );
  }, [view]);

  if (booting) return null;

  // Intro sengaja dilewati kalau langsung masuk ke area admin.
  const introVisible = showIntro && (view === 'portfolio' || view === 'projects');

  return (
    <ViewContext.Provider value={{ view, setView }}>
      <LanguageProvider>
        <AnimatePresence>
          {introVisible && <LoadingScreen key="intro" onDone={finishIntro} />}
        </AnimatePresence>
        <ScrollProgress />
        {(view === 'portfolio' || view === 'projects') && <CustomCursor />}
        {(view === 'portfolio' || view === 'projects') && <Header />}
        {(view === 'portfolio' || view === 'projects') && <WhatsAppFloating />}
        <SmoothScrollGate view={view}>
        <div key={view} className="animate-view-in">
          {view === 'portfolio' && (
            <div className="relative min-h-[100dvh]">
              <div className="relative z-10">
                <main>
                  {/* Fold pertama — eager, jadi LCP cepat.
                      Efek "kartu numpuk": Hero sekarang nge-pin DIRINYA
                      SENDIRI lewat GSAP ScrollTrigger (lihat Hero.tsx) —
                      durasi pin-nya otomatis ngikutin tinggi Hero yang
                      beneran, jadi nggak ada lagi wrapper manual dengan
                      angka tebakan di sini. About (z-index lebih tinggi +
                      background solid) geser naik nutupin Hero yang lagi
                      nge-pin. Sengaja CUMA section 1->2 — section-section
                      lain tetap scroll normal biasa.
                      Urutan: Hero -> [numpuk] -> About -> Skills -> Packages
                      -> Portfolio -> Footer. */}
                  <Hero />
                  <div className="relative" style={{ zIndex: 10 }}>
                    <About />
                  </div>
                  {/* Di bawah fold — lazy. Fallback dikasih minHeight supaya
                      layout nggak "jumping" pas chunk masuk (CLS = 0). */}
                  <Suspense fallback={<div style={{ minHeight: 200 }} />}>
                    <SkillsCarousel />
                  </Suspense>
                  <Packages />
                  <Suspense fallback={<div style={{ minHeight: 400 }} />}>
                    <Portfolio />
                  </Suspense>
                </main>
                <Footer />
              </div>
            </div>
          )}
          {view === 'projects' && (
            <div className="relative min-h-[100dvh]">
              <div className="relative z-10">
                <main>
                  <Suspense fallback={<div style={{ minHeight: 600 }} />}>
                    <AllProjects />
                  </Suspense>
                </main>
                <Footer />
              </div>
            </div>
          )}
          {(view === 'login' || view === 'dashboard') && (
            <Suspense fallback={<div className="min-h-[100dvh]" />}>
              {view === 'login' ? <Login /> : <Dashboard />}
            </Suspense>
          )}
        </div>
        </SmoothScrollGate>
      </LanguageProvider>
    </ViewContext.Provider>
  );
}
